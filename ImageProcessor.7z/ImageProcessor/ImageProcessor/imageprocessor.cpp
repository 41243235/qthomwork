#include "imageprocessor.h"
#include<QDebug>
#include<QFileDialog>
#include<QMenuBar>
#include<QHBoxLayout>

ImageProcessor::ImageProcessor(QWidget *parent)
    : QMainWindow(parent)
{
    setWindowTitle(QStringLiteral("影像處理"));
    central = new QWidget();
    QHBoxLayout *mainlayout = new QHBoxLayout(central);
    imgWin = new QLabel();
    QPixmap *initPixmap = new QPixmap(300,200);//設定初始大小
    initPixmap->fill(QColor(255,255,255));
    imgWin->resize(300,200);//設定初始大小
    imgWin->setScaledContents(true);
    imgWin->setPixmap(*initPixmap);
    mainlayout->addWidget(imgWin);
    setCentralWidget(central);
    createActions();
    createMenus();
    createToolBars();
}

ImageProcessor::~ImageProcessor() {}

void ImageProcessor::createActions()
{
    openFileAction = new QAction(QStringLiteral("開啟檔案&O"), this);
    openFileAction->setShortcut(tr("Ctrl+O"));
    openFileAction->setStatusTip(QStringLiteral("開啟影像檔案"));
    connect(openFileAction,SIGNAL(triggered()),this, SLOT(showOpenFile()));

    exitAction = new QAction(QStringLiteral("結束&Q"), this);
    exitAction->setShortcut(tr("Ctrl+Q"));
    exitAction->setStatusTip(QStringLiteral("退出程式"));
    connect(exitAction, SIGNAL(triggered()), this,  SLOT(close()));

    //放大影像
    zoomInAction = new QAction(QStringLiteral("放大&L"), this);
    zoomInAction->setShortcut(tr("Ctrl+L"));
    zoomInAction->setStatusTip(QStringLiteral("放大影像"));
    connect(zoomInAction, SIGNAL(triggered()), this, SLOT(zoomIn()));

    //縮小影像
    zoomOutAction = new QAction(QStringLiteral("縮小&D"), this);
    zoomOutAction->setShortcut(tr("Ctrl+D"));
    zoomOutAction->setStatusTip(QStringLiteral("縮小影像"));
    connect(zoomOutAction, SIGNAL(triggered()), this, SLOT(zoomOut()));
}


void ImageProcessor::createMenus()
{
    fileMenu = menuBar()->addMenu(QStringLiteral("檔案&F"));
    fileMenu->addAction(openFileAction);
    fileMenu->addAction(exitAction);
    fileMenu->addAction(zoomInAction);
    fileMenu->addAction(zoomOutAction);
}

void ImageProcessor::createToolBars()
{
    fileTool = addToolBar(QStringLiteral("file"));
    fileTool->addAction(openFileAction);
    fileTool->addAction(exitAction);
    fileTool->addAction(zoomInAction);
    fileTool->addAction(zoomOutAction);
}

void ImageProcessor::loadFile(const QString filename)
{
    qDebug() << QStringLiteral("file name：%1").arg(filename);
    QByteArray ba = filename.toLatin1();
    printf("FN:%s\n",(char *) ba.data());
    img.load(filename);
    imgWin->setPixmap(QPixmap::fromImage(img));
}

void ImageProcessor::showOpenFile()
{
    filename = QFileDialog::getOpenFileName(this,
                                            QStringLiteral("開啟影像"),
                                            tr("."),
                                            "png(*.png);;bmp(*.bmp)"
                                            ";;Jpeg(*.jpg)");
    if(!filename.isEmpty())
    {
        if(img.isNull())
        {
            loadFile(filename);
        }
        else
        {
            ImageProcessor *newIPWin = new ImageProcessor();
            newIPWin->show();
            newIPWin->loadFile(filename);
        }
    }
}


void ImageProcessor::zoomOut()
{
    // 確保圖片縮小
    int newWidth = img.width() / 2;
    int newHeight = img.height() / 2;

    // 使用高品質縮放方式
    img = img.scaled(newWidth, newHeight, Qt::KeepAspectRatio, Qt::SmoothTransformation);

    // 更新 pixmap
    imgWin->setPixmap(QPixmap::fromImage(img));

    // 調整視窗大小以適配縮小後的圖片
    imgWin->resize(img.size()); // 設置 QLabel 的大小與圖片匹配

    // 如果 imgWin 是 QGraphicsView 或其他容器，可能需要調整視窗中的內容顯示方式
    imgWin->setAlignment(Qt::AlignCenter);  // 讓圖片居中顯示

    // 更新 QMainWindow 的大小
    this->resize(img.size() + QSize(20, 40)); // 加一點邊距，使視窗稍微大一些
}

void ImageProcessor::zoomIn()
{
    // 放大圖片
    img = img.scaled(img.width() * 2, img.height() * 2, Qt::KeepAspectRatio, Qt::SmoothTransformation);

    // 更新 pixmap
    imgWin->setPixmap(QPixmap::fromImage(img));

    // 調整視窗大小以適配放大後的圖片
    imgWin->resize(img.size()); // 設置 QLabel 的大小與圖片匹配

    // 如果 imgWin 是 QGraphicsView 或其他容器，可能需要調整視窗中的內容顯示方式
    imgWin->setAlignment(Qt::AlignCenter);  // 讓圖片居中顯示

    // 更新 QMainWindow 的大小
    this->resize(img.size() + QSize(20, 40)); // 加一點邊距，使視窗稍微大一些
}

