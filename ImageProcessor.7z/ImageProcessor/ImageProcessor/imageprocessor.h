#ifndef IMAGEPROCESSOR_H
#define IMAGEPROCESSOR_H

#include <QMainWindow>
#include <QAction>
#include <QImage>
#include <QLabel>
#include <QMenu>
#include <QToolBar>

class ImageProcessor : public QMainWindow
{
    Q_OBJECT

public:
    ImageProcessor(QWidget *parent = nullptr);
    ~ImageProcessor();
    void createActions();
    void createMenus();
    void createToolBars();
    void loadFile(const QString filename);
private slots:
    void showOpenFile();
    void zoomIn();
    void zoomOut();
private:
    QWidget *central;
    QLabel *imgWin;
    QMenu *fileMenu;
    QToolBar *fileTool;
    QAction *openFileAction;
    QAction *exitAction;
    QAction *zoomInAction;
    QAction *zoomOutAction;
    QImage img;
    QString filename;
};
#endif // IMAGEPROCESSOR_H
